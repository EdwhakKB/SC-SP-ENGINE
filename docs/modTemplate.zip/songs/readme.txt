Put your custom songs here
It should be a folder with your custom song's name, and inside of it should include two files: "Inst.ogg" and "Voices.ogg"